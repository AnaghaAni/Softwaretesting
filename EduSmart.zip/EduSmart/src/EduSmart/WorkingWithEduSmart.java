package EduSmart;

//Abstract base class for all types of users (Student, Instructor, Admin)
abstract class  User
{
	// Encapsulated user details (accessible via getters/setters only)
	private String name;
	private String email ;
	private String userId;
	
	//getter Methods
	public String getName()
	{
		return name;
	}
	
	public String getEmail()
	{
		return email;
	}
	
	public String getUserId()
	{
		return userId;
	}
	
	
	//Setter Methods
	public void setName(String name)
	{
		this.name = name;
		
	}
	
	public void setEmail(String email)
	{
		this.email = email;
		
	}
	
	public void setUserId(String userId)
	{
		this.userId=userId;
		
	}

	
	 // Parameterized constructor to initialize  object
	 User(String name, String email, String userId)
	 {
		 this.name = name;
		 this.email = email;
		 this.userId = userId;
	 }
	 
	 
	// Abstract method to be implemented by subclasses for showing profile
	 public abstract void viewProfile();
	 
	 
	 // Final method - cannot be overridden, common to all users
	 final void displayWelcome()
	 {
		 System.out.println("\n\t\t\t--Welcome to EduSmart LMS Portal!!--\n");
	 }
}


//Interface to be implemented by class that can track course progress
interface ProgressTrackable
{
	abstract void trackProgress();
}


//Student class extends the abstract User class and implements the ProgressTrackable interface

class Student extends User implements ProgressTrackable 
{
	 
	Course enrolledRef1;
	Course enrolledRef2;
	int countEnrollCourses ;
	
	// Fields to store up to two enrolled courses
	private String enrolledCourse1;
	private String enrolledCourse2;
	 // Private progress counters for each course
	private int progressCnt1;
	private int progressCnt2;
	
	
	
	 // Setters for course progress (Encapsulation)
	public void setProgressCnt1( int progressCnt1)
	{
		this.progressCnt1 =progressCnt1;
	
	}
	
	
	public void setProgressCnt2( int progressCnt2)
	{
		this.progressCnt2 =progressCnt2;		
	}
	
	//Getters for course progress (Encapsulation)
	
	public int getProgressCnt1( )
	{
		return progressCnt1 ;
	}
	
	public int getProgressCnt2( )
	{
		return progressCnt2 ;
	}
	
	
	 // Constructor using super() to initialize User fields (Inheritance)
	
	Student(String name, String email, String UserId)
	{
		super(name, email, UserId);
		this.enrolledRef1 = null;
		this.enrolledRef2 = null;
	}
	
	
	// Method to enroll in a course (max 2)
	public void enrollCourse(Course c)
	{
		
		if(enrolledRef1 == c || enrolledRef2 == c)
		{
			System.out.println("\nAlready enrolled in this course.");
		}
		else 
		{
			if(enrolledRef1 == null)
			{
				this.enrolledRef1 = c;
				this.enrolledCourse1 = c.getTitle();
				countEnrollCourses++;
				System.out.println("\n"+super.getName() +" is enrolled in "+enrolledRef1.getTitle());
			}
				
			else if( enrolledRef2 == null)
			{
				this.enrolledRef2 = c;
				this.enrolledCourse2 = c.getTitle();
				countEnrollCourses++;
				System.out.println("\n"+super.getName() +" is enrolled in "+enrolledRef2.getTitle());
			}

			else if( countEnrollCourses >= 2)
			{
				System.out.println("\n"+"Enrolled Courses \n");
				System.out.println("1. "+enrolledCourse1);
				System.out.println("2. "+enrolledCourse2);
				System.out.println("Cannot enroll more than 2 courses");
			}
			
		}
		

	
	}
	
	
	// Display enrolled courses
	public void showingEnrolledCourses()
	{
		if(enrolledRef1!=null)
		{
			if(enrolledCourse1.equals(enrolledRef1.getTitle()))
			{
				System.out.println("\t\t1. "+enrolledCourse1);
			}
			else
			{
				System.out.println("\t\t1. This course has been removed.");

			}
		}
		if(enrolledRef2!=null)
		{
			if(enrolledCourse2.equals(enrolledRef2.getTitle()))
			{
				System.out.println("\t\t2. "+enrolledCourse2);
			}
			else
			{
				System.out.println("\t\t2. This course has been removed.");

			}
		}
        if (enrolledCourse1 == null && enrolledCourse2 == null)
            System.out.println("\t\tNo courses enrolled yet.");
			
	}

	
	  // Override method from abstract class to display profile (Polymorphism)
	public  void viewProfile()
	{
		super.displayWelcome();
		System.out.println("\n\t\t\t Student Profile \n");
		System.out.println("\tName: "+getName());
		System.out.println("\tEmail: "+getEmail());
		System.out.println("\tUserId: "+getUserId());
		System.out.println("\tEnrolled Courses : ");
		showingEnrolledCourses();
		
	}
	
	
	// Update progress based on course title 
	public void upDateProgress(Course c, int progress)
	{
        if (enrolledRef1 == c)
            progressCnt1 = progress;
        else if (enrolledRef2 == c)
            progressCnt2 = progress;
        else
            System.out.println("Course is not enrolled for the student.");

	}
	
	
	
	// Implementation of interface method to show progress (Polymorphism)
	public void trackProgress()
	{
		 System.out.println("\n\tProgress Report for " + getName()+"\n");
		 if (enrolledRef1 != null)
		 {
			 if(enrolledCourse1.equals(enrolledRef1.getTitle()))
			 {
				 System.out.println("\t\t" + enrolledRef1.getTitle() + ": " + progressCnt1 + "% completed");
			 }
			 else
			 {
				 System.out.println("\t\t1. Course has been removed.");
			 }
			
		 }
		 
		 if (enrolledRef2 != null)
		 {
			 if(enrolledCourse2.equals(enrolledRef2.getTitle()))
			 {
				 System.out.println("\t\t" + enrolledRef2.getTitle() + ": " + progressCnt2 + "% completed");
			 }
			 else
			 {
				 System.out.println("\t\t2. Course has been removed.");
			 }
			
		 }
		 
		 if (enrolledCourse1 == null && enrolledCourse2 == null)
			 System.out.println("\t\tNo courses enrolled yet.");
	}
}


//Instructor class inherits from abstract class User
class Instructor extends User
{
	// Private fields to store titles of two created courses
	Course createdRef1;
	Course createdRef2;
	
	private String createdCourse1;
	private String createdCourse2;
	
	// Counter to keep track of how many courses the instructor has created
	int courseCount = 0;
	
	// Setter for createdCourse1 (Encapsulation)
	public void setcreatedCourse1(Course c)
	{
		this.createdCourse1 = c.getTitle();
		
	}
	
	// Setter for createdCourse2 (Encapsulation)
	public void setcreatedCourse2(Course c)
	{
		this.createdCourse2 = c.getTitle();
		
	}
	
	// Getter for createdCourse1
	public String getcreatedCourse1()
	{
		return createdCourse1;
	}
	
	// Getter for createdCourse2
	public String getcreatedCourse2()
	{
		return createdCourse2;
	}
	
	
	// Constructor to initialize Instructor using super() (Inheritance)
	Instructor(String name, String email, String UserId)
	{
		super(name, email, UserId);
		this.createdRef1 = null;
		this.createdRef2 =null;
	}
	
	

  // Method to create a course. Instructor can only create a maximum of 2.
	 public void CreateCourse( Course c)
	 {
		 if(courseCount >= 2 )
		 {
		     System.out.println("\nCannot create more courses. Limit reached!");
			 System.out.println("Course 1 : "+createdCourse1);
			 System.out.println("Course 2 : "+createdCourse2);
			 System.out.println("\n Only two course is allowed !! ");
		 }

		else if(createdRef1 == null)
		 {
			 this.createdRef1 = c;
			 this.createdCourse1 = createdRef1.getTitle();
			 System.out.println("\n"+ createdCourse1+" has been created");
			 courseCount++;
		 }
		 else if(createdRef2 == null)
		 {
			 
			 this.createdRef2 = c;
			 this.createdCourse2 = createdRef2.getTitle();
			 System.out.println("\n"+createdCourse2+" has been created");
			 courseCount++;
		 }
		
	 }
	
	 
	 //Method to show the list of courses created by the instructor
	 public void showListingCourses() {
		 if(createdRef1 != null)
		 {
			 if(createdCourse1.equals(createdRef1.getTitle()))
				 System.out.println("\t\t1. " + createdCourse1);
			 else
				 System.out.println("\t\t1. This course has been removed.");
		 }
		 if(createdRef2 != null)
		 {
			 if(createdCourse2.equals(createdRef2.getTitle()))
				 System.out.println("\t\t2. " + createdCourse2);
			 else
				 System.out.println("\t\t2. This course has been removed.");
		 }
		 if (createdRef1 == null && createdRef2 == null) 
		 {
	            System.out.println("\t\tNo courses created yet.");
	     }

	 }
		
	 
	// Overrides abstract method viewProfile() from User class (Polymorphism) 
	public  void viewProfile()
	{
		super.displayWelcome();
		System.out.println("\t\t\t Instructor Profile \n");
		System.out.println("\tName: "+getName());
		System.out.println("\tEmail: "+getEmail());
		System.out.println("\tUserId: "+getUserId());
		System.out.println("\tAvailable Courses: ");
		showListingCourses();

		
	
	}
}
	// Admin class extends abstract class User (Inheritance)
class Admin extends User {

	    // Constructor calls the superclass constructor (super) 
	    Admin(String name, String email, String UserId) {
	        super(name, email, UserId);
	    }

	    // Method to simulate removing a user from the system
	    public void remove(User user) {
	    	super.displayWelcome();
	        System.out.println("\n\t\t\tUser removed: " + user.getName());
	    }

	    // Overrides abstract method from User class 
	    public void viewProfile() {
	        System.out.println("\n\t\t\t Admin Profile \n");
	        System.out.println("\tName: " + getName());
	        System.out.println("\tEmail: " + getEmail());
	        System.out.println("\tUserId: " + getUserId());
	    }
	}

// Course class 
class Course 
{
	// Private data member - encapsulation
	private String title;
	
	int durationInHours;
	
	// Final variable - value cannot be changed once assigned
	final int maxStudents = 10;
	
	// Getter for title (Encapsulation)
	public String getTitle()
	{
		return title;
	}
	
	
	// Setter for title (Encapsulation)
	public void setTitle( String title)
	{
		this.title = title;
		
	}
	
	
	// Constructor Overloading:
    // Constructor to initialize only title
	Course(String title)
	{
		this.title = title;
	}
	
	// Constructor to initialize title and duration
	Course(String title,int durationInHours)
	{
		this.title = title;
		this.durationInHours = durationInHours;
		
	}
	
	// Method to show course details
	void ShowCourse()
	{
		System.out.println("\n\t\t\t Course Details \n");
		System.out.println("\tCourse Name : "+title);
		if (this.durationInHours == 0) 
	        System.out.println("\tCourse Duration: Not yet started");
	    else 
	        System.out.println("\tCourse Duration: " + durationInHours);
		System.out.println("\tMaximum Student : "+maxStudents);
	}
}



public class WorkingWithEduSmart {

	public static void main(String[] args) {

	    //1. Create courses using both constructors
	    Course c1 = new Course("Python Programming", 10);
	    Course c2 = new Course("Artificial Intelligence", 10);
	    Course c3 = new Course("Automation Testing", 20);
	    Course c4 = new Course("Core Java", 20);
	    Course c5 = new Course("Manual Testing");

	   
	    // Show course details
	    c1.ShowCourse();
	    c2.ShowCourse();
	    c3.ShowCourse();
	    c4.ShowCourse();
	    c5.ShowCourse();

	    // Instructor creating courses
	    Instructor i1 = new Instructor("Sree Hari", "hari@gmail.com", "In100");
	    Instructor i2 = new Instructor("Anjali", "anjali@gmail.com", "In101");

	    i1.CreateCourse(c1);  // Python
	    i1.CreateCourse(c2);  // AI
	    i1.CreateCourse(c3);  // Exceeds limit

	    i2.CreateCourse(c3);  // Automation
	    i2.CreateCourse(c4);  // Java
	    i2.CreateCourse(c5);  // Exceeds limit

	    i1.viewProfile();
	    i2.viewProfile();

	    // Students enrolling in courses
	    Student s1 = new Student("Athul Krishna", "athul@gmail.com", "Std1000");
	    Student s2 = new Student("Diya", "diya@gmail.com", "Std1001");

	    // s1 Enrollments
	    s1.enrollCourse(c1);   // Python
	    s1.enrollCourse(c1);   // Duplicate
	    s1.enrollCourse(c2);   // AI
	    s1.enrollCourse(c3);   // Exceeds limit

	    // s1 Progress updates
	    s1.upDateProgress(c1, 90);
	    s1.upDateProgress(c2, 10);
	    s1.upDateProgress(c3, 0);  // Not enrolled

	    s1.viewProfile();
	    s1.trackProgress();

	    // s2 Enrollments
	    s2.enrollCourse(c3);   // Automation
	    s2.enrollCourse(c4);   // Java
	    s2.enrollCourse(c5);   // Exceeds limit

	    s2.upDateProgress(c3, 50);
	    s2.upDateProgress(c4, 90);
	    s2.upDateProgress(c5, 0);  // Not enrolled

	    s2.viewProfile();
	    s2.trackProgress();

	    // Admin Actions
	    Admin a1 = new Admin("Admin1", "admin1@gmail.com", "Ad1101");
	    Admin a2 = new Admin("Admin2", "admin2@gmail.com", "Ad2102");

	    a1.viewProfile();
	    a2.viewProfile();

	    a1.remove(s1);
	    a2.remove(s2);

	    // Using setters (encapsulation)
	    s1.setName("Athul Krishna G");
	    s1.setEmail("athulg@gmail.com");
	    s1.viewProfile();
//
//	    //Simulate course removal by changing title
	    c1.setTitle("Machine Learning");
	    i1.setcreatedCourse1(c1);
	    i1.CreateCourse(c1);
	    i1.viewProfile();
	    
//
	    s1.viewProfile();       // Course title mismatch should be shown
	    s1.setProgressCnt1(95); // Resetting progress manually
	    s1.upDateProgress(c1, s1.getProgressCnt1());
	    s1.trackProgress();
//	    
	  
        }

}
